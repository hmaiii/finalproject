#Maedeh Hajmalek  , Mina Ebrahimi ,  Amir Reza Mirtajadini,  Mohammad Hossien Shamsipor
def odd_even(n):
    if n == 0:
        return 0
    elif n % 2 == 0:
        return 1
    else:
        return 2


def square(n):
    return pow(n, 2)


number = int(input("please enter a number:"))
print(type(number))
if type(number) is int:
    print(square(number))
if odd_even(number) == 0:
    print("zero")
elif odd_even(number) == 1:
    print("even")
else:
    print("odd")

letter = input("enter a letter:")
while letter != ("q" and "Q"):
    letter = input("please enter another letter:")
